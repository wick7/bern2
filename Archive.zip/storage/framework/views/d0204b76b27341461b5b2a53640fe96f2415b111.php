<!DOCTYPE html>


<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="A portfolio template that uses Material Design Lite.">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
    <title>MDL-Static Website</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:regular,bold,italic,thin,light,bolditalic,black,medium&amp;lang=en">
    <link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.indigo-pink.min.css">
    <link rel="stylesheet" href="css/styles.css" />

    <script src="https://code.getmdl.io/1.3.0/material.min.js"></script>

    <link href="https://fonts.googleapis.com/css?family=Fascinate" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

    <link href="https://fonts.googleapis.com/css?family=Barlow+Condensed|Bevan" rel="stylesheet">

    <script src="https://code.getmdl.io/1.3.0/material.min.js"></script>
<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
  

</head>

<!-- Uses a transparent header that draws on top of the layout's background -->
<style>

.demo-card-square.mdl-card {
  width: 320px;
  height: 320px;
}
.demo-card-square > .mdl-card__title {
  color: #fff;
  background:
    url('../assets/demos/dog.png') bottom right 15% no-repeat #46B6AC;
}


@media  screen and (max-width: 600px) {
    .section-three--title {
    font-size: 4rem;
  }

  .sec-three--con {
    left: 1.7rem;
  }

  .fall_title--main {
    font-size: 3.5rem;
    font-weight: 300;
  }

  .fall_title--sub {
    font-size: 1.5rem;
    font-weight: 200;
  }

  .about--title {
    font-size: 3.5rem;
    font-weight: 300;
}
.sec-three--text-con {
        top: 5rem;
        left: 10px;
        width: 90vw;
        opacity: 0;
        transition: .8s ease-in;
    }
    .sec-three--text {
        font-size: 1.4rem;
        font-weight: 230;
    }

    .sec__four--title {
    font-size: 4rem;
}

.sec__four--text {
    font-size: 1.4rem;
    font-weight: 300;
}

.section__four {
    height: auto;
    background-color: white;
}
    
}

</style>

<body>
    
<!-- Always shows a header, even in smaller screens. -->
<div  class="mdl-layout mdl-js-layout mdl-layout--fixed-header">
  

    <?php echo $__env->make('partials._nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


  <main onscroll="scroller()" id="main" class="mdl-layout__content">
    <div class="page-content">
        <div class="fall">
            <div class="fall_title">
                <h1 class="fall_title--main" style="color:white;">BERNALESE</h1>
                <h3 class="fall_title--sub">...do you speak it?</h3>
            </div>
        </div>
        <div id="about" class="about">
        <div class="mdl-grid mdl-grid--no-spacing">
        <div class="mdl-cell mdl-cell--12-col">
            <h1 class="about--title">Character For Your Home</h1>
        </div>
        </div>
            <div  class="mdl-grid  mdl-grid--sec-two">
            <!-- <div class="mdl-cell mdl-cell--2-col mdl-cell--1-col-phone"></div> -->
                <div class="demo-list-three mdl-cell mdl-cell--12-col mdl-cell--4-col-phone">
                <ul id="sec-row" class="mdl-list mdl-list--two">
                    <li  class="mdl-list__item mdl-list__item--three-line">
                        <span class="mdl-list__item-primary-content">
                        <i class="material-icons mdl-list__item-avatar">home</i>
                        <span>More Than A House</span>
                        <span class="mdl-list__item-text-body">
                        "Bernalese" is a retail concept in progress which builds upon the eclectic notion that many aspects of collecting and acquiring are melded together to create a home.
                        </span>
                        </span>
                    </li>
                    <li class="mdl-list__item mdl-list__item--three-line">
                        <span class="mdl-list__item-primary-content">
                        <i class="material-icons mdl-list__item-avatar">build</i>
                        <span>In Development</span>
                        <span class="mdl-list__item-text-body">
                        Our flag ship retail store is forthcoming in San Francisco, California - stay tuned! A vast array of antique and contemporary items will be available exclusively in-store for purchase.
                        </span>
                        </span>
                    </li>
                    <li class="mdl-list__item mdl-list__item--three-line">
                        <span class="mdl-list__item-primary-content">
                        <i class="material-icons  mdl-list__item-avatar">shopping_cart</i>
                        <span>Online</span>
                        <span class="mdl-list__item-text-body">
                        A curated assortment of vintage and world-craft items is available for purchase via eBay.
                        </span>
                        </span>
                    </li>
                </ul>
                
                </div>
                <!-- <div class="mdl-cell mdl-cell--2-col mdl-cell--1-col-phone"></div> -->
                
            </div>

        </div>
    </div>

    <div class="section-three">
    
        <!-- <div class="mdl-grid mdl-grid--no-spacing">
            <div class="mdl-cell mdl-cell--6-col mdl-cell--2-col-phone section-three--title">
                <h2>Antiques</h2>
                <h5>\anˈtēks\</h5>
            </div>
            <div class="mdl-cell mdl-cell--4-col mdl-cell--1-col-phone photo--1"></div>
            <div class="mdl-cell mdl-cell--2-col mdl-cell--1-col-phone photo--2"></div>
        </div>
        <div class="mdl-grid mdl-grid--no-spacing">
            <div id="texter" class="mdl-cell mdl-cell--6-col mdl-cell--2-col-phone section-three--text">
            Antique...of or belonging to the past.  Vintage, collectible, the ultimate recyclable.  Whether it is the cookie jar that rested on your grandmother's kitchen counter; the mid-century coffee table; or the Victorian candlestick; these items are what make a house a home.  They speak of personality, history and aesthetic, combining to give your home that special character.
            </div>
            <div class="mdl-cell mdl-cell--2-col mdl-cell--1-col-phone photo--3"></div>
            <div class="mdl-cell mdl-cell--4-col mdl-cell--1-col-phone photo--4"></div>
        </div> -->

        <div class="sec-three--con">
            <h1 id="sec-three--title" class="section-three--title" style="color: white;">Antiques</h1>
        </div>
        <div class="sec-three--text-con">
            <h4 class="sec-three--text">Antique...of or belonging to the past.  Vintage, collectible, the ultimate recyclable.  Whether it is the cookie jar that rested on your grandmother's kitchen counter; the mid-century coffee table; or the Victorian candlestick; these items are what make a house a home.  They speak of personality, history and aesthetic, combining to give your home that special character.</h4>
        </div>
        
    
    </div>

    <div class="section__four">
        <h1 class="sec__four--title">Homeware</h1>
        <h4 class="sec__four--text">
            Not just a houseware with utility, but an item that supports its function with style, simplicity of purpose, and a bit of craft & creativity.  A "homeware".  Maybe it is locally produced or coming from afar, but it carries a special quality that contributes to making your house your home.  These items fold gently into the fabric and character of our daily lives.
        </h4>
    </div>

    <footer class="mdl-mini-footer">
      <div class="mdl-mini-footer__left-section">
        <div class="mdl-logo">
        <span class="copyright" style="color:white;">Bernalese&trade;</span>
        </div>
        <ul class="mdl-mini-footer__link-list">
          <li><a href="#">Help</a></li>
          <li><a href="#">Privacy & Terms</a></li>
        </ul>
      </div>
    </footer>


  </main>
</div>
<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
<script src="js/jquery.js"></script>
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/scrolling-nav.js"></script>
 
    <script>
        
        var myVar = setInterval(setColor, 5000);

        function setColor() {
            console.log('Yay')
        }
        

        // window.onresize  = function() {
        //     if (window.innerWidth < 525) {
        //         console.log('smaller');
        //         document.getElementById("texter").style.fontSize = "9px";
        //         document.getElementById("sec-three--title").style.fontSize = "10px";
        //         document.getElementsByClassName("sec-three--con").style.left = "0px";
        //         document.getElementsByClassName("section-three--title").style.fontSize = "15px";
        //     } else {
        //         console.log('bigger');
        //         document.getElementById("texter").style.fontSize = "15px";
        //         document.getElementById("sec-three--title").style.fontSize = "95px";
        //         document.getElementsByClassName("section-three--title").style.fontSize = "95px";
        //     }
        // }

        function scroller() { 
            var elmnt = document.getElementById("main");
            var title = document.getElementById('title--two');
            var row = document.getElementById('sec-row')
            var info = document.getElementsByClassName('mdl-list__item--three-line');
            var antique = document.getElementsByClassName('sec-three--text-con')[0];
            var antiqueText = document.getElementsByClassName('sec-three--text-con')[0];
            var x = elmnt.scrollLeft;
            var y = elmnt.scrollTop;
            var currentWidth = window.innerWidth;
            console.log(y)
            console.log(window.innerWidth)
            if (y > 1265 && currentWidth > 320) {
                console.log('classadded')
               antique.classList.add('slideUp');
               antique.style.opacity = '1';
            }else if (y > 1265 && currentWidth <= 320) {
                antique.classList.add('slideUpMob');
                antique.style.opacity = '1';
            } 
        }


       
        

    </script>

</body>

    
</html>


